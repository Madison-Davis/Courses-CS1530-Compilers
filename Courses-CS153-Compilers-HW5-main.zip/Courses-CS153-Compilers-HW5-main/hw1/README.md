# HW1: Hellocaml!

The [instructions for this homework](doc/hw1-hellocaml.html) are in the `doc` directory.


Quick Start:

1. open this folder in VSCode
2. start an OCaml sandbox terminal
3. run `make test` from the command line
4. open `bin/hellocaml.ml` and start reading and editing!
