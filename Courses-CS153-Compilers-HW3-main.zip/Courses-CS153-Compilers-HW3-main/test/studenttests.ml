open Util.Assert
open Gradedtests
    

(* These tests are provided by you -- they will be graded manually *)

(* You should also add additional test cases here to help you   *)
(* debug your program.                                          *)

let provided_tests : suite = [
  Test ("Student Test 1", executed ["llprograms/student_test1.ll", 1L]);      (* all cmp statements, out-of-order jumps *)
  Test ("Student Test 2", executed ["llprograms/student_test2.ll", 1L]);      (* argument registers are saved *)
  Test ("Student Test 3", executed ["llprograms/student_test3.ll", 42L]);     (* advanced gep checking *)
  Test ("Student Test 4", executed ["llprograms/student_test4.ll", 28L]);     (* gep: nested struct indexing *)
  Test ("Student Test 5", executed ["llprograms/student_test5.ll", 1L]);      (* call-by reference using arrays *)
  Test ("Student Test 6", executed ["llprograms/student_test6.ll", 55L]);     (* test global indexing *)
  Test ("Student Test 7", executed ["llprograms/student_test7.ll", 37L]);     (* pointer chain *)
  Test ("Student Test 8", executed ["llprograms/student_test8.ll", 36L]);     (* gep: nested array indexing *)
  Test ("Student Test 9", executed ["llprograms/student_test9.ll", 24L]);     (* any function pointer with call *)
  Test ("Student Test 10", executed ["llprograms/student_test10.ll", 44L]);   (* BST Insertion Tree*)
  Test ("Student Test 11", executed ["llprograms/student_test11.ll", 45L]);   (* Linked Lists *)
  Test ("Student Test 12", executed ["llprograms/student_test12.ll", 66L]);   (* Function callbacks *)
  Test ("Student Test 13", executed_io ["llprograms/student_test13.ll", ["\"password123;\""], "-4557880398663063474"]);   (* djb2 hash algorithm *)
  Test ("Student Test 13.2", executed_io ["llprograms/student_test13.ll", ["\"hello cs153;\""], "-4569957541237689240"]); (* djb2 hash algorithm part II *)
  Test ("Student Test 14", executed ["llprograms/student_test14.ll", 1L]);    (* fibonacci *)
  Test ("Student Test 15", executed_io ["llprograms/student_test15.ll", [], "1\n3\n3\n12\n20\n21\n42\n60\n100\n888"]); (* bubble sort *)
  Test ("Student Test 16", executed ["llprograms/student_test16.ll", 0L]);    (* map and fold *)
  Test ("Student Test 17", executed ["llprograms/student_test17.ll", 22L]);   (* inversions *)
  Test ("Student Test 18", executed ["llprograms/student_test18.ll", 42L]);   (* null arguments *)
  Test ("Student Test 19", executed ["llprograms/student_test19.ll", 24L]);   (* null GEP *)
  ]   
